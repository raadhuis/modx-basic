
DefaultResourceGroup


Author: Bob Ray <http://bobsguides.com>
Copyright 2013-2014

Official Documentation: http://bobsguides.com/defaultresourcegroup-tutorial.html

Bugs and Feature Requests: https://github.com:BobRay/DefaultResourceGroup

Questions: http://forums.modx.com

Created by MyComponent
