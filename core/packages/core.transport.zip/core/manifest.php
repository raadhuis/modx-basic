<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1418e169f7ee0f5b2ceee70c9fefde35',
      'native_key' => 'core',
      'filename' => 'modNamespace/92baff070a433c776f3c49787525daec.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '7065494e8006cea751d8b4206f5abc1f',
      'native_key' => 1,
      'filename' => 'modWorkspace/7c6e37506abead4c72147e583a63887f.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '27c70dadb282d4a9dbb82aac5debb446',
      'native_key' => 1,
      'filename' => 'modTransportProvider/7512013515486933bff76a89f15589f2.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '544f585fe30f0eb0f25fb88e25838ed4',
      'native_key' => 'topnav',
      'filename' => 'modMenu/dd54e9994d3be32f589a52491b8caeab.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '52810e3b1854bafe7f196c8fc5513b54',
      'native_key' => 'usernav',
      'filename' => 'modMenu/fb5b79944065dd30777e391f34a86ecb.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '2a1b1d6355134a360e24ab5d653dd48b',
      'native_key' => 1,
      'filename' => 'modContentType/91e1c3158d7cfa8e2dd1273199aafbe0.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'dc377003fa91ffd698d7d43659c5e419',
      'native_key' => 2,
      'filename' => 'modContentType/e2af3758b00eafc1587f92bd89de4109.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b3f6a900a17e0523561ce76ef8a8c5fd',
      'native_key' => 3,
      'filename' => 'modContentType/f61932394bdf56f14d1204e793d9954d.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '89efdcf99142de92fd4873667518844c',
      'native_key' => 4,
      'filename' => 'modContentType/b71944b526ae25b54c93a9813be52c41.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f9857cfcea64b783ca2149590aad0b84',
      'native_key' => 5,
      'filename' => 'modContentType/fe4a4572ac0c0dc783fde3b5b8e09c49.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b07ad48fcb57cea6269ab7bde1c884a8',
      'native_key' => 6,
      'filename' => 'modContentType/9f00402c6e1b477eb6f56f890f92c826.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '17a7b768f32b841395358cb2642dd5b5',
      'native_key' => 7,
      'filename' => 'modContentType/709ebfdfe8927e72e4536f3c89e01a3c.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '617ad57b692b87fb0c334a4e589eee97',
      'native_key' => 8,
      'filename' => 'modContentType/d0b543ba469cd02ec6051e6f673e66eb.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '71f0345bcb41c552614e28a3cbb945f2',
      'native_key' => NULL,
      'filename' => 'modClassMap/9fb858eb1d8fb87d93972de8132ab342.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '72ed530a499bd72321431393f2f1911c',
      'native_key' => NULL,
      'filename' => 'modClassMap/568dbb7021034b06f6cb6aa3ba05d521.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'eb4c8d22b51f8c9b73a1a75a528f8665',
      'native_key' => NULL,
      'filename' => 'modClassMap/91a9b7fa4d0b693bba23c4d11651bba9.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8c743a958f2fdb1b1d10a463e4846908',
      'native_key' => NULL,
      'filename' => 'modClassMap/48a3f78b03d606da395b4ce4f3b7ad67.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f83ad9de339bca98623a35010dd539f0',
      'native_key' => NULL,
      'filename' => 'modClassMap/b3bd5df98a4724cf236a834d582033dd.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f233e830033f72465e68d00f52cebedf',
      'native_key' => NULL,
      'filename' => 'modClassMap/0973d05761b778e6568a49d134e6ba5f.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '05ae326645c67ba29244bb16c24a7e94',
      'native_key' => NULL,
      'filename' => 'modClassMap/9ce31d3c54f2a88e24c629c3e2e9d168.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'bcd3b5ae80dab72e1c7c114e514ed425',
      'native_key' => NULL,
      'filename' => 'modClassMap/cc19bbcc00345e0f1901b8d9ddd1d127.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a2950463494cadc88e64639ed35a9c80',
      'native_key' => NULL,
      'filename' => 'modClassMap/e0dbf2a42e8f23f8b678129212feed3b.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59415f4f18d8fe31210b8726fc9bdc08',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/d3944cef51ba04e8e917f0d7df182c1f.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb849ac50e9e5960545f0db426af4f87',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/19e3ce832801aa1797daa5ac4b7a8bc2.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca0f8d464e22bcaccdbbe90cf5073df9',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/c9ab137280e66a00868f7de38800848d.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18b39ac68bed26d199b91811b6bc0da3',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/0164dacea8ee0c2f530a61bce7f15ce5.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd36afd3eb3b6af9f9b09d2143dc1f459',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/9c317ddde1acc9c5e4f47c0a7d3538e0.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de593c0ad9e7721c1b32743a32b57fbb',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/59ae7954f94a79d85193c5f7394a6fdb.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '121c61483e57f34f613a6f8e214c0832',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/5725365cb4d5ce5da27bec28fa8f9547.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '140907cc0ca3c8a44f8b7cc05075af99',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/83cf065059b0020cd62b100d0564052a.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31850d4b701d0b025f895854069b4697',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/78e6dfce6e8a7a13987bd05123d5040a.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '097f0a924518a9ca5c64c63086a44632',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/0e60dbed65b6bd56ba57089801ee9433.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3610a0df17a1e91a7336b2a33e415289',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/302eadc7a2d082549294995a93cee017.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c277fc0a62bff788d894319998c55ea',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/b1de6eebd12184272f54d69f19a710f6.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2506335c5fe2e3376488333d5506d853',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/70e2b6141bdf6ac69e9f2f345e420763.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4eef59058e4943648f59307348c5b757',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/98d584d5211920aec82de2ea98463c14.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '516cd7a57711a201f2d349daddbf6319',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/7fa5e48b161fd285bd924bd188f1d305.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd56afceb7742f8e32f0254a25525865e',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/164d2f6102bddd0399c554e65d473285.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad04af2758b8caafdadcd1f8e2fec4c8',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/1641ea61664eee26b3b58e4a755298c2.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '591cbb4bfd77fef2c8a54080d9a75f3f',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/014bd51717967ccfdc938d14b63086e9.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '358a4443418232039022775af1becc9f',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/64ab2ba7a0691cb06675cc259f2807b9.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f519d96a00ec1aed521a307c313822b5',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/5bb8d70273a1812ef6441b3463b553c0.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d33f2d2b7b3e215427b17395a60b11c',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/a35a2b4a1d1d7e8d011f9317e25cc38e.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5facaca0d367f78b8d8342f9169aa01',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/51ee6a18044224acf8b5e0dc08dc1011.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac89f88391cfaba46456ff83f81cbdaf',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/52483830f6a8cce084cd5fd0f6c27e11.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6cdb80240424cd53afc6b4a32edd752b',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/e073ab7a86bb76d37f392a8808627329.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18434c792a38bcc617992157a195ac65',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/503373e7f8cc3992383ba1a22083b1e1.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0de5a2791f1cbb62e79c0bcceae29b0',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/5e4c3bef05357640299ee0cc666e135a.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66f9b5968d5e2bf22c0be72e56031db5',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/185cc3d3856aa5d766da2c30fa656576.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3018e253952f6311595f4e1c66b7d471',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/b6490190cd411c8d2564b7f15315b1ba.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e894c7b3b28f990aa6939fa6a05d4b2',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/4c0be8782a06ca6d67a4257996b7943b.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2a21b58c200cf479eaaff2a8fed600c',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/937de7fa129d914ab681aa3de712754b.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '729431dc25e82a9af31efc543a4a2e54',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/a47cc5c75c82c277ab2258aa82499fba.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c403ab19d0428d5ffeb0a14b8f304b0',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/d2e44726aa1a843cd5d86f108982499b.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '024716ccbdc0a14eea83bae9e6bcc585',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/10bc20d54491cd8f387fe59340086040.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '82fc65cd94e498820610cf37fd818eda',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/4363776d4225c74d2a3d225cc8816628.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fff51290be47f40c7792a4f6fbe02594',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/185a2a4364fe0d06c87d8c5b76364a2b.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '494adee1ccd8af39104f2ce2c65d4fb5',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/ac5df5b522ec96bae3787a5193e4868f.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '228a3b0289b7e3f7f4f9164a72275935',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/a3fa235359b726e38556602a3f344dfd.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ab5cc01a8abba396a2b007db6254966',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/34ebd62dfa4bb0ea0547d3a2b5d813b4.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebccbbc97a6e421d46082b90f700fe4e',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/06b7e419dbb2a22a378a9fc3af1a5399.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18f65ba02fc0a01be6c808397e769cfa',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/fe26b50613bfd5eb9c84e2adb4e467b3.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18a31ba3e62ee9cae34b6e41ffdbe74e',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/ea6589899ef602f43f20f75858aa53da.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '404ab6df6e4bfa6b122a99cba427884c',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/ed87f7f2261ce4bd5881075539961fbb.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7931958906615cb408046da98f25652',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/676b21911d8521173bb8949244780eb4.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff21f9c76f9fe9cdf019dd29b4ab3eba',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/0ec115458a2b58612b10f3b9b6f4bf8d.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5fba7e468d2af27f61a3c78f986ec48',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/a7bdd5bf7c2bdf4d3af335b2d941dd9f.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f2100a79781e0a163513818fc40f774',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/2bf71b2afe2f6e79e5c8f36d1794efe1.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f18ce716326f8ca802e511cbf8c2d4d',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/a61dbef550143e7c9ba12c09eccd97d7.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '226e0bd4bb068c47939a2d767d8c3398',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/bf91e2754a855588f29fa40e7c129854.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f69e449bd229e2c2a521988d1e1add7',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/279954828345ec4bc4eee48a6142b130.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '69162058a3b460b7c875c34215e5c557',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/f4623d54e9c2f945446e56341124755e.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03719b584dacdbcf4928a2257d75eef5',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/fb79f1937241d7cb6d7aff21e99058de.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f60aa0dc81ad62befc14085571cf78e6',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/a8d091e0722c74c8d7bb550d57e325d5.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a9972d25a1b478e689c9a686b8bcb16',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/83cd2502b37032a58f48259e33e5c488.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02bbb546d77f1019088c9e106cf1ceb5',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/771051f248331545abc9e711785bd91e.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bb3881b8bfa57c5ca0bdd3722945c1d',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/1e7540bf8e15e2eaa728b2f3f41e4e15.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65a7a7f6fb8ad247cbbee5bafd177cc3',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/e6055e5d52edde39b110818d3d7a7f5d.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70b695419c9328583fc4095c0f0f990e',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/df921e669b1f47af3984c023ef2172b1.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '582e181eac00e8342723bb4297dd3df6',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/b0356057663e1843c658bff03070310e.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a4fc39893f2fa82baed1aab8a7a19d2',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/f46a64965e150e60d00836a1a4d4c99f.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85bb8add09eeeaf10f0377b3475e1dfd',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/78b7967969f0a4e059fb7a082d4b83ce.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bffef05bdcb30f743f7ab7f8f707359',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/ec6aa7e7af6523e85d5d08eb448a3b43.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9b83f55a444e2e1c5d46cee79773e63',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/b6d2c55fb9c0344c03defbd0a3589223.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dac61473ee175027144a073542a53738',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/0f1481c196731b8ea4dd3094a3e6f1fe.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f97df7e979a6f178422f625c904bb70b',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/927f86149ef635e1d46d240ac9978aab.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e1140facb74900303e3ec3260072307',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/263908044d966c1361a597bf66b3cd5b.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c02fb365d83e2dfa8549fb9d2d944d5',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/5575fb3e2bb7ec03085ee7fb3953e21f.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4cba9cdf9453fbfd2b2ee65efbbeeb04',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/f893f33d77ef853a13f1975481160547.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8df82d3be06cf56d155d4328464734a4',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/e72add7a63e58681722ee5c81d7959b2.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a538d28e800670f08717aa7e6cb49469',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/fe344ad434361cc0f51c26559d0f4f2f.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aae1eed55a90ee4da7eb2bedbb55de81',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/bdfa7e81b0d572626e778a48a2a3242d.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '54026261e48beed85557a54120e10c41',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/63ae727afe8082586b1e0e71c1cd5e2d.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b6e18ad252c12b603947dd0ca2b0627',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/375826627942fc7430efb4a92a7d7e0c.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4d99e48b3a1237cadbae5c0f9d3d91a',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/989cec4fd5c87d9bc890ef760bec9213.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d5ac9a434d78a7292a7c47aa459f3f5',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/9e2d8a85d2a52fdd8e88ee5cdc9560c1.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '21fd9184965a2601ee45b0410ca9b715',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/0a488f40a89916d3a20def38030c77e3.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba74b615c7cc7e4fe060c916161ba47e',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/d33ffdebfbfdb0da77a6136d6613e6f0.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e5b4ba0586b3bff4ed5114d48d77f06f',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/7a21cf481823782959cd892441e7f1f6.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ea5771f6f4be9347c0b85a852522697',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/1bb2ab16f3d426eb72aeac7126fdaf40.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b703dfa2433b211fa8b4f4ff718acc79',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/e727c348cf62bbc9c3cc1f7ae248926c.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '72ea284860986b1a41356386ad07f4ae',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/638f8fde6c75fa06501f2dc549bc8b19.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07a8ff4f143dd7fbd3a5df911fc90818',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/844273cc94e3da33eb82bde197f62008.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d5525f2d4ec859de43a8379a9790112',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/93a336c2beee43a9423b7e2d07e7b4d2.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df93ddd75800a7adad55d7562f4fc602',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/e30fe47558479a66b449f0e2f2ff0846.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ba8a6114c9c3c09623837967ff916d8',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/04020613e3cadf1a621e2e7a5b0613d5.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd150371ce745af5be1f830d191354ae1',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/8f79a0b6895df14a3049b50c4743e6b0.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d113b7c751a47283f73d208bc6d40f5',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/eac9e09636c2c15c44b96e70dfbd7219.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0cab6c016704d6bbb577abbd4da62de',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/397cc0d845fae61074da1244352fd2e3.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a14ca9224631f56385c9ad0f1f5e3d8',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/47e1d50c9756a303f9cce7d6e564eed7.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81d6e0925079d5aa3d77580465a7cb6a',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/14ce8f4b7a689787ce337d848843996e.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f401827f4fa4d01210e75679ec948f6',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/36c77ab84faa5a1c5c15d17a6892b794.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d3d71e0af61c72240f4245b2ae17c71',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/e775046c44eecf57851f1618895f9c1d.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '434c7fae7525646f29b3df46cdb40110',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/3223c9b5e7f1616c3073f9318658f1ab.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8050477d32ca51b2dcada1c6c870c0a2',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/19aa68fd59cabc11e92b7953fa6dbdcb.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ec9ccc4ee9e9147f90ec09494ff8b8e',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/8b4b9cfa96f8ca3436523fdcce523be4.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b5b2eeb5a0926dd0f342e0a138eb0b27',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/f380c0b09e49dd675b4c8a6a187c6d16.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3722b17d1ba40f31dd8245b0e71e6b76',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/a746b0311407b84ad2225a46799cecd6.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94c1aea92e7bac2bfd8530a7697b14b2',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/9c77ca41669646fc1706e7a4474bf103.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7262febcc47cb21f1af1227506fb5561',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/a545efbfe0f15a92a4ee5393075b1a86.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5fd2875aff8236dc6ca064d901e8963a',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/f2d2459541d271836267043f5e96ab4d.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6663c7d506eed29303e6035357ef050f',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/2886bb1514739faa46225d23c3dc0ed8.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aeeefe4e729be4a6e510daee874c226a',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/0dee1a0adf86d559b4484f561c5366cc.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad1929dd9a11cb5f3eb8d6014ae72758',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/127d31abfea5d4e94cbe9a1e3f6851c1.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9dd788b63aff594d35e1ac2fc36f810',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/54316ecf39e962291f395767f33cd031.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c134df89f9f554aeddc6609d95876eb2',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/1b947f7ff4f16caa216febf96f09bf22.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f6d742cfc64ae6e7ac6084598d63454',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/403de5020fc7dc284697c4744c9db539.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8dbaaa81255e3ff59f3501c1af3da9d',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/796065fbc1f7effdafa7cf635e118b81.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c91a2c5a9d9885b97b4cfc709b640d2',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/fa3a1660431796d90067775a7aae8cf8.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f10918ab802082da84cfdb219bcb7640',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/14a77f981d99e0ad98b3c49d5e589a2b.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b96d35f2b7fb8945c4c225048da212a',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/1803c20daf972ab2b06857475a8b3c07.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f480cabc486b6bf39279b805f5a4a26f',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/71fe1db85aaaf39c6609ae1e8743990a.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4939a6cc827750d2911d93f5bab34bdf',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/af60db934d07943189db0a8ecab77a8c.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e88f6a290d5f84e715c2148b4fe55c7',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/b42a442366565ff2921ab79df7d476c9.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d59ff7b3a1aaca1d8757e96105e34c2',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/4a46dd30b46961ebd1c6afab0600ac1e.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f5cad4b73e9a756d4462d1fd4e52e57',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/3fc64523ad38e2de03243b8647856f4b.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be0b0106ee41736185c3608afc0e0b08',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/ec276210cd1b76b154c649ffa6c4edf2.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b631ee6fae6d2f7a072f03cc180c5867',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/3049881c8472651045f0ce5501bb2459.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a5e76c5fca2d09f81009018f4b1847d4',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/439108107a432b0c53613d477ccf336e.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ff7cf93bcb883cc279aa9ba1ad6d31f',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/5cf25c9aab6558f636282b1166bdf403.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a254843360c00bbd80c635dc185ca1bf',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/45020e1d3ba884c099b73e60444c4f77.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f58113b048279b8f561c6db031c9153',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/c79ae450ac4e9bf89ee12ca9dff77425.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78a8002d58313e492618dd24e0695ccf',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/35c9b6d387f21162c6d9c9b57d6cbd64.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05c37bd4b5a4d9db3f8611a60f471f4d',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/bd4a5b934102016e8351b41f79157709.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e24680e2eda598baabebdc6545c7620',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/c80d9fa81edac579e818e07f9b77d963.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd82ca31db9e1bf27c2bd5168217b182f',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/ada7877b75adf4deaa44840c8f4882ed.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d60addf156ee3bbb5a1c8f9a8ef6895',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/30e61a53dacb2a4bf25e024e5a4b3cc4.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2beaa73f031c0cfcfe3368d38e6d3b5a',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/269028828cb5ee43557d5968e4b29bf0.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b3bbd00c71e1f1b496f0f617a1eca54',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/4f4bb8c5ef765720152eb1442de66280.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '863ca56f649384ce9d917c47d36778ed',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/db03e67038a047401e6c4a0a18af7c10.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10982db59cf9a8ee21ab92e728643685',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/38a6c834f9d74359c6b5c7a7dc2a5a5d.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a96e8e798e369159291925e53e46d35',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/be9cd137745307c1f41758d9740af782.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fd489aa276d03b5d7a24be5cf61944f',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/ecc0ef320ec208435a5b2183830d135b.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00e58f7e877f26a528a7227583c33955',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/f328598b69bb42c865f9bbd1138b226a.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17618f3b7befcbe291e5bdd90399d7f8',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/ec1a945e0f33bce511a064e2d76d8f19.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a4e8f4b1b0ed4a2cb93766e5fe10832',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/1704530e991202efbce91998f8ca1aae.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e7e5c70f6747dee7b57e2bff75b1340',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/d7e405d7180af38b39f008593bc71b6c.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca66f95816bbfb754bd5eefdfb1a4203',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/10973fc3bfa8caee60fe3c0e19f058c2.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37255b6884fbbd99f28363c84c6184e9',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/36ecda3a5d354cba7ad3c1677d5a91fc.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0064656350e6e291df8e064721801186',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/434c23e6f47cdfa695da20cc1a0628d8.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e974253214013f5c368bc0d898bf196',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/e168ef49a74e1c2d53ec936cc5beeb73.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fe6903c3910f457853a4143398deccd',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/f21223c9dd5f3998bba968022ddd5205.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e6521f03b93bb8438173cba3b3eecd1',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/5d7139debd28534aae2fd54da685c6fd.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '980e5fe9180230fa7616095326fb2246',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/637927281409966943c2b47531204bf4.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4182c19f1f743c647622c1bea196ace',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/48003fe8472d9b8d781eaf73f40aee29.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e97300453e62090716a15243ed65b123',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/b3a9e02006f8841b8a8421a00b7c0d55.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5befa240a3f2de24cfdd476c16dd9141',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/bba9a9566ef8cdb332312b1de2161c34.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2392128edcad74d8fe7798459557bc1',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/46cbec1eb4730e251c5dc5fad3c4ed11.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b349a10cf0abb14db5af4cbf2bb39bef',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/be09b7d11c5efbe42fc344d43cac3ad4.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d80586634f53747af5e75228d814aa9',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/d09886ab01ba57390a78b23871dfa9b0.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee30686fe859b08a075897e4fbf1fc9e',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/64f815027124363dc3a7b5a27ad8eec0.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49c31d509708c840b700f11246a2bac4',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/5e5c3f8113807999fba576a3f4263d5a.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '381091229457812f88f4fa93d8b13462',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/40efbd31cc2107ff26e219bd0aa6b7d6.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44bd6fbf25746a3ca3d79b5144110d14',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/df36ec2789b6bff56b4236ceafd4ef00.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5790ce55918270a19569b20b51e479bd',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/1b76449b23e32c93ef74eb6dc60cc269.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39a999ba19a693e756b49c6bfe824912',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/4b467bc3b55229ba532319c47e73ca96.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b02111540e8036734b3bed27289e4151',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/43418ecdab7f2dce049c2c25719e224f.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd777d1c4f492426348f77db04359aa11',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/5a8e59570523784d162f78cb41f1151e.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '471e496e6c366334ba8e0f32686bbb7e',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/de7ba8968211ed85b2c76b4ff102c9fd.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8c55e0779d3884c2dbc2539d946af5d3',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/b14d31ec031aa577901d0ddbb41f93b9.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f02a03f2f52063be5a0ef84339f66ce',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/bf3db837b82a2153f6700bf75d9fa8bf.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c15467d697865a4fe956d13dd5e335b',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/749d8b08dcda46e5c888b6c477689710.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df9f93ad94bd52468563293da5bf4178',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/9195c3ffe033214ba7e8621e5f6f08f7.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '280761f59a96f9c007a910f584c561e5',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/6ce24348e6ac32f89d8c9336813e1fae.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19dfa1df488ec99f84c0ea4f6fb3d685',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/805eb3d506675d74c80617f9fd3f35b6.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1ee9bac45f7c3cb51b388c058e67de1',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/34e821ef708c9dac22a7c29ee12fc8df.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6b19f3d4e327bce97a9de5f3e13ab1a',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/b96cb9bcec8206cbe4ccce4f70e9c779.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d463c2f2c7c9bbdf8ae40d47a9a626d',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/7bd13ecbacdb76d093d6bde0441f3862.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b51d33bf42e5f8532b1a107ca083b17b',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/17e1848043d4567090683b2b914eb2ae.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8675f88e64d7ba9617a29926083fd252',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/a526397f5c8aa36a63749f2840db21df.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '215f0f51c1afa99e4f0debac22bdccb3',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/214b130286c74d2843f9b75c15bfeeb5.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b592644cd5f296f947c2f6b3e9d8fcb8',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/34cd676e79e23c0ef257b947cdbf75f8.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be5f9da4d8dcd9b7b4bc571448b909f2',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/2f73c326ae811bd951f2c2ef0ff95fb0.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c18dfff429338ad9299e4b359e223ec6',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/ddd18d8f9e32713f76d455d8d4e273ad.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0d745f5c126aad6705f22d12287e8b1',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/ea6c03640e7f619e813ac839283f17f5.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35bce325678a7b04230042f0f755e3b5',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/9b14b9b1195b9de690e4be004558778f.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a9c7121d43e386a8b7af54e1009983d',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/f6cb6644f39cc98044509003900eb705.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9180ee2fab3a4801615602050f41f744',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/5f8f5bb2e2b47f64536c993c72b84788.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd69ef875556b2e5879797343a2222208',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/d9be03d728de420f986f4cfdfe8f63a8.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a475f75ac3d1c0febd347de598bc678',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/92fd05542e1025a0aece8f7e0c69e9f7.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7088f493c092b30eb3b1d02d4f0c704a',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/7abb3a394d89039ffcf52c01a5dae875.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3226829eab435bcdf0320e5e3fecc1b8',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/641a9db16349d5adaa4d5628e0577d81.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '798927d659f1af99bc554970c259957e',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/2bebf85d2ff88a6a97a454acf8d31865.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3a01d09a6bd378bcc51553ba5047c18',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/74b06375b2177f0821ad77334ddc99e1.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22b0b1a47a87007e79731f3ab01e6ede',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/da308f75effa6ad2f431c51c55b206d6.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e632434f7627a25ba398dc38fddbef1a',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/1ef7d1460f39f95cba5b83b18fa675bd.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2598c8b38b08aeab3e00bb655b52aae9',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/a331f0b4a97ace3cb134b31cd660f9c5.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c078a5835f35912d8c38e072d83ffe2e',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/c1edb27213b221c3869104b719bd4ab8.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2245831e4db932d9d1ba9f80864fc704',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/727d21e09c2d6dfbf0937e86e19e48b7.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cd37f1300954df4d8cdee8873dd32dc',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/ea5c41c0f0e58d90049565b338b15330.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b961a77c700d9cca4594c9f2a0b8cabc',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/556980c1f2e858f3fdd0bb7e215031a0.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2836eefc9794fc9cd52ba8d862c8c571',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/59b18e3bd53cbcbe17c3098449227a7b.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '794317deac1e80ba6826c2d25d75934e',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/3b3911c21fc9850deedef92041fa77c2.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6da716a9fa631821a45b80def3ea7fbd',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/393a4774529d86ae6f3b747c8ad2cfe2.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f724097eda7c72b76daacaf52eb7dca',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/74383c043ecf010a0eda629590275569.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b01ad599af06318aa8fb96eebbf98c57',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/0fd023d5003615b7ff1c87bc84b6bd22.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee6c9d09342c0ab19013d2c8224f5c3e',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/b93ecfb3da19cc868768aa9ac0964288.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9532c93721ff8f5d56d7086d77abc86e',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/4bb63d4ca79fd2fc6d90cbd1ed6aeaa7.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a844c5c06be239f2e1eb38a35c621ad5',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/3124044d5052b64ba05596182baebcda.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50220935fa45f63b3594c0efa0456b60',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/9416b22fac810e0d22302afdd9916e42.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa650dfc0c36a20912f0925db9bea802',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/025dae89385c5ba22368e21ba20c64c9.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09695d9c400b6bf6f06f0dd0b67d4d53',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/f66a27d1c8b43035091269b70b3132a8.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e147b2620f8c903a7da494f9fcb9dfd7',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/69ab8349da68d9052bfd382d7c6ecec5.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a456eba5c8bdc2cce10f885ff3fc1de1',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/776b31f47473ab1dc2613ef764d5d187.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '850d189efff926d497dafeae2a478f7e',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/08d30b9c2ab32b38d5c32db5b07dad38.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23ae4ef1a8a299dc798240697ec680be',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/2bff85daedbd02e3eb01e712bd898781.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6f2938ed7ab6f7eaa6ae70dbaaffbba',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/9f836591a1f3f77ef1c472c52ff13df1.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ad7ac3becf72fc4bf431ac3d819bea9',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/0755bd3d6d0a699427bc2e92b13ed92d.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41c1ce5517a4cfbf25c87242f6fdf0cc',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/e9070d4ad5c92ea6cd2a9b76087e97f4.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49d8bcafa489a6b3af13000ad2e7f127',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/77a3e4bc7e800b705f32f95255c58bb0.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a936e3afd896269d1740d2e71c0dba84',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/59ca8023d5531c66a582567a33f68e82.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5869a0018e2537beeacbf61e3f0d639',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/4ea7b5b2edf176ee1e7a93b9b1223564.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '458082585f720e6a4f5919ee70c4bd76',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/0441d28c543bfdcba7bfee04c4d149db.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62d661c84fee58a74fb007fb2bdbbfa0',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/a42841f1dcf1ab3c2f681a79186ebabf.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3e60152e61d2e23dbc449f2db6652e7',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/173b468df4ee46723f80854c3b5a43eb.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3696f8373b2bb6a9f5dfffcd33289d27',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/769f8a3cb9d6193dd644140badde36aa.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3604425c4c8cc6fecbd04f8e8f62dbff',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/a0a612294e6207f9f8626ba9fbd2f548.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '635e983ef90e7237e52ab1bd27902607',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/c792232c8b48657581159f27f6c62906.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de51cd8f3e8a88b22420e448783aaf1c',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/28ed26d0c24c8e026b7b2bf800292445.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0023f3097eff7aafae22cf5df4b095c',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/9e718db9767ea81ae57d723b6cb180e1.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd555a1b9725c21b8cf7f35cb0be570b2',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/be007961d6897e9e290dc3253dc15f88.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccee76a0d3ae886327ad879c593a8974',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/36690c4432e47fee34fb89e54a997a22.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3dae7e86dea7a439f4c510a677f7a74',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/ceb4d59f041dade93a5da2e9f82e0d60.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bd1df4614851fcc89250ad6d6caa796',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/95f4fb33f3bdc83749bd7ae6c1a69d07.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd33d160339d4f3ef0e7593216235ce0',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/66fd8e8a63bf9ccd18a78a94b1916069.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ed64799699ebe6eb99f42cfaecd451a',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/b62f9c8451c86f824fbabd6dcf48ab32.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f4c9b086b15dbb5cb577dff916f20ae',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/154a1ac31787afbd201884bea9ced9bb.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2673b6b40d2155aeeca2354e211eae1',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/ef63a2c4c5a4531874b4b31e1cba57d2.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bc0e0ba4cea4d828e054347a65630fa',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/3ef778caf339d244c7a4f9881be6f4cb.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff609306c378ec6e2d11ebd03bacaa0f',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/f1a15f8d532afc5d9d7e7db9d74a406e.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca759d257c073e3124ece79281d93e7a',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/ce0f32ec8ea462be8c7b64cff2d5f30f.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '930176df4cf2630218c6d06cb82a32aa',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/4853f0ec1279c5f11ea77e6fe495e080.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41710e6c1e7b914552ae6fb42fb007e5',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/970b1bfffd251e890442508104101b35.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57e030193accf321bfad5a3d3da022c9',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/172e5d5ac0aaa3ebbe9545a925f4ab7a.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a8de0a52900d490953b5f3a6cb41775',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/2e5a834e6d02ca0b1dd59661ae4ae036.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '694a562148f1782fd9aed336641421ac',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/3c84ae044abda6a8fcaf137397222e7e.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7db0abfa68eccc28fa3c7508064a4d4',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/8f4dedc686171ccfac53c5e52cd3191c.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a66bb6a9c86d1bb1e984c3737706f4cd',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/4fa64d44e97deaec56bab05bd0de1d2c.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0e2c816bf9e1aa21ecae0bc9c57b895',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/1b1ff22e9a5de5615e76d636a2f51210.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e317e23035de05aeab60a4f8505fba5f',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/09f69084f58413a53c8ba1a0602c8f6a.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '346770c01c5c88c284e1a30907b4203c',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/3f3de1389e98bd7be16ff9204d9849fc.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bf7146a493d8bd8323bc94e5196b80e',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/ff2060db8ae2d276a4440a568fceb421.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11b386122e2eda0fb417c2ba9b22e7b3',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/114ec16b0f39192ee9bcef80df28f221.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46dafc851c5759ea3650ac42aa1d0213',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/625c87f9f570801048bac43d51c051d6.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aec7e538fc44e0cf12ea0ae71aec7649',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/95d1b66c1c549fe85710a0e316c4ce27.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ad1695fc32a20ed6cf79c2b90c34fbf',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/bb6348c0c77f304af426ff45fee7a966.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55b66410850f9c0e1d63187020d1ed96',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/9b2c22948dd1d80e4a339112d2c5b492.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b424abc65fc4b8f39a9c2a70e6fa2161',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/2e14c762ed9362363001d89ce8a18600.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '872f79b4557ae995cc610f0d4fa50963',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/31d3fe0b4f7a9db5c489ce6796b529f4.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '360c1deaa1185bb45f29f955acfc0a48',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/639cdb516864a84a432310bd578aee71.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51031932a0aa03a21d69878edcba104c',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/36590a61a6d70737c3928f7378a84e0e.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc25bf6c5383066c52c13133011ce07c',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/ca0a043a0fb7a3ec088cdd64bcd1ade0.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '942f1e799b433f25b126c40b21a7c3a1',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/6c37ce6d14e7d3dd96a969d1bb059b42.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93ff08f795f59f1acdfb03769c917c2d',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/0e06dce15b89398df17d884ee779180a.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6dbcc04180996fdddbd596c599b13ddf',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/3d4246aeb8293d9f2287bf181f8261ce.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bb243f755cf7e09fb5164b6c3ce8f46',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/0c6caf1e03aba63264005c68c6d155ab.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6d2bfd19c1c12d52fce2db7225fecaa',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/0b6b16ad0ae7dbec54f2c88a17db7ef0.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7595abd5dff5eb23e0bf80002b2dea9f',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/2dc38f4851bfd01b6bf3c550eeb1201c.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e0f7c6acbfd129799c40641e54f7fb8',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/defc790b0f004722fd0de15642d4b75e.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ae23252d31a72d3ce1c6bb6491b3356',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/49546e2e2808f10d8332347054e9ee41.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eddef79f3e843a1a662dfdf2ede7e628',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/af8fd625553e8d2f727be359cb4aa96f.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5dda857f60c8daf5a185e30654c4707',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/a34928eb1e8a863f88fdc863df21b880.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd459bd4ed25deb40fbbec01c2e3314cb',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/2777e92cb9e766468e706e0975aa36d3.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64b4acebaddbeaa5507c8477697630df',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/a64a099b7f5356eb5d884286c79e6f55.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0982289f96082bbdef306c5d8964dbbc',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/b9ac27530c9813490854fd9ce1cb49d6.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b7696974e8c0deb0b572f6ee940bb00',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/d3fd2eaf4e4a2432e20711786b954fdf.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03310db58c6b75c738a259d4fa2bb03e',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/8140ba0db2a21aa528d98dacf6d643c6.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebb7a86fdf16c3a15cede05153375e7b',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/f3594f688b2b61054ef7b85c3953dff3.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09cc48c959947c8ba2662efb50d52cd2',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/f6eaeee15a8eb066a0a821d030943f20.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a72aac52623fe445c75092207e8109b',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/a936f3b94cef1b42fb764431f223768b.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c991a917983d91ca5c2cff9248c40fb',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/46f5c54beaee28297bbd9fea5b42b1dd.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71e4756ca106928cd8ead2e9450f300c',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/bc26e59383cb9bb9255b68159348fef7.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a572987b7839e741067305287b1717c',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/dbcf9bdcdcfc2a246f62ce0cda1aa05d.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90442309cc41fecd906d5cd5666cd701',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/b8e905e48bb9bd5bce3ab1e3ffa053d9.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79f4e36198ba58fe178edd9211560c14',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/e7d4db8a28b4872d921e8664a2e91502.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b62a37d4e622fac96185892e3353f9a9',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/2c146d3098f6af859bd22dc75a3226be.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55420aec11fb1c1d8163021324ee2c0c',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/3da7be725971e03f493787b07ba908a7.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a78b5d58aeba17b24fb8402e35f59c25',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/eec8b14e4506fbabd6bb3dff3e55f9ad.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b8caa45c31d88044c9372be42e25292',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/743eea3fe37a3ff51e49e85c18e9c85f.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0759177466626d13916836cc520762d7',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/7298e0feac5344b2847d58884c9bf9e7.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39b3ca38e7ba6cfe03405aa0ce5cf55d',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/531206aacaa366b4e197fdf773aff8bd.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e606c65a15c38af842c5157c0521909',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/e3cc7d6115006118086d8a0ac2c61315.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '132fff31272b9c3008874b2586261800',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/7782573497c442b7b810f956b78c348b.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be979b290c0c2973b9e308d01ef7ff50',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/1de0d1f53b5a2a7b2d9ecda5e6a397b9.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f5e7e874b824d2c44f05f2ef80458b0',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/27b21a433513ff9aab1c1847e709ae81.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b87b0c4bc7309569704a9bf21069cbd3',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/0005a85f3babfa578d22141dba56dacc.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11b5666a9143b2f43a750134137b5973',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/76a47379fefa166cd7c82f707bc111c8.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f9bc31576c1a140e5f6f9ffcd02756c',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/614c22e34e7abda6005f6a3941c39ea0.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce59826623ce52f39f4c2a6af378b774',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/550bbf04c59e63160ccea99330832b77.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e390137c33e19cea295cc752ea10433',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/01845ff813a74ee3988d9d6083f864d4.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5070fb6b1fb6af7c51fc25d64898cf13',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/8ddf40c8a6236faaa0796dcbd90b5dc8.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af108776ac718ebba2b6d72abd08c274',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/3a4d1462c17a628c55529f9b78778a24.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '851f6ca9a81afe9cd6380469b6e04bb1',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/c65796e1de34cbe74e9f235a388ca430.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09f10d98e16a92b3530dc7ae022dc925',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/d312d4c24b909e64778410dfbb4f1920.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f137c40afc3b92a8c5ca0f12270cb597',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/971abc95c3ae666d0ce545762ef741ac.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '529c02d41b684028d3939c6c683408bc',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/5e1d9aac4873a0af5db6066964201fa2.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '253ce691a758730541f588cc55aeed66',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/3639c184006996bc5e4dc220db4be4c7.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f262e102b65956a4d712e6ed94d910fb',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/9ffec15832c85b5b54c698c60f6cd471.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1eeb70ef85e4bf2b64668edccc8ddcc0',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/293ab6236f59fc21f6e708ec12f3db72.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '101bb90440f25ca54391061663e96dd8',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/0f8e573f690bf714d5ab12d5f0e2e948.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '412cb08bcb023c201dd6c8a53d100830',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/650b0765fb596939264791e2471b054d.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1da6ff42251db0f043d9ad326532f139',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/78d43d4b2c0731c7053a1e0578ff739a.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3c1f8c474593da31b502bec51711a4a',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/d27fa7883277a5da00a51a5e7d04f3a9.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e170baf08651a40064cc1421b416c69',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/5df35cbd9717c30e545e4e8c6bd2a7ab.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80e0f8cbb73123ba14546d0afc0e5e1f',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/78268ea088962a79b10cf42b71232646.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3f3ae93261eb6eda4b4b1c83136c587',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/965b6399cf8bab3d82e2d8dd186944ac.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad97dd76f65355db9459108435efcf62',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/b6972f631ae19c04a5cea07c2e6f8694.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '124910b995f6aee479abccb5eacd9cf8',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/afe00948bbcabaf946b664c5ee0bf9c3.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b6c0014e45791b67f235840b1c27ed2',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/156bd0db6161ceba89763080b81e55cb.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd966502749d63fa08dcceeaca0f55eba',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/447c0699db4e643386d9f1f6badcd04c.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28c5c4d49d0cf15d2de6474ab203fead',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/47ebcc43e2894e981cccbb409320ab0a.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d99de8ba09f44c00c18076257cb76e9',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/5c8fd27916869fe0fa392fc7b6e7effc.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef77d769890eeb23c262c76762bd6be7',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/c8716a46d463811f479db5e99105b451.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '669d66bd97ef25b782cd9f0c34ad062a',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/deb66be27b505f5199fa45f3025afc26.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59bbadceb20973fbb84ab7b54368c7d8',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/4302db3033bfd55ff6127ad070f2c1db.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fd5951f64e68f3b7c608dbea55b148a',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/c55a733255a1df5eb5609cf8cf631c64.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64cd52c829b1b916d833eadabb97ca4b',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/fd488a03a2b679be50001026fb795072.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45d0315fd1a49156c68b67ad6578b3e5',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/da4ed2fa72e8370bfeec3c1053f14fbf.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6576a330e66114eea649aee8d40cd1c4',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/a0a2d7c2642e0ac35d5bcdcf401a772b.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17bb4f1d3e0b82de76536c1aa6b411d0',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/60cec629189df6b7335f3b5a9f50fa2b.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79eb7c9b678dab5e70c3f2fa92e5ae02',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/b98c0013ffb5003e4bcb8f4ed0928244.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27c7827b297817a92b8965241b5ad001',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/ce7d188e4eb8137e2a91c56a427ad095.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d4965a05d05ed6988c6802ce70491ae',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/42b7a7492d038bdb8363360df5759085.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa02bad48c828ae97aad99a51376c711',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/220426a4860f224e32ba915ee112c06c.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf790e5f64b54b387ffd04c894804b4d',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/a1e9d9ebef454b9fbf5444d6ff6c2103.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa3ea5b9fadc7417621a37abfde1b5bf',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/1f2b037eb559ae518ff3f236ddfcebdb.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8c30d2a67cf7c606994efa0f5f8cd08',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/681b0fdc4ef296e0e03ff1864af44b9e.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '865d85f06c5f3d008d49bc2fd775e19b',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/a04b0f92a3ce832d3f1d264d45472704.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e2a95e9f6096e5a6d9be27a58d7eea8',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/1e5c4840c3c851699e853faec1743527.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cb7be25a69b3fd50baa1287825fdfc1',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/a3539e72c26f3314bc503ab1e94134fa.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8399cfd7ad2f749c55ea9d6f831ea84e',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/30da938fbf762c6af4993f2e4aa67f42.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'acfe3766b972d4d54ea052147dfd498c',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/ba2aec11f53f7b23ab7ddfa689b725da.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edb0fbd6aecc69dd67f5932ea44b89af',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/16e5bf71a6d28e3a0b335685b0c9ef5e.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4d76b329154f4308463ce80f977fa26',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/0ab72ca51dc76cd87cea3a4270a1de84.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99096eeaa547f981717e67375aa5ed3c',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/3af3308c5d79154fa41763bf7c579a11.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5051407f9cee77e48d9c7f75e73bcb21',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/3e4024bc4b53f555c4880bbfae1e4eec.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9db2d9a3a2afe5baacd5fc6ca12f22f',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/c0eb4874ecd77b7671664df72ae688da.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd52b585389997d62e09762503f1adc31',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/7a8b2dbbd4726bd1d91e9253cfef5423.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f509c873444d6554c32e66a28392875b',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/a635b81280f9f2ac6340e5b3a6531fcb.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b03ae8d765b7e9b88d5813083e13622',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/815b7bf646e7500dec8d992e9f240d67.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78b3bb839a0bf95ab2aca80dae2186d8',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/0fce5cda114539608c26078ffb403c02.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '686d6aabd6cda5d034c763312937ae32',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/b7ef02995db994a7efc3f377cebed4cc.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfca86e520b6c3115cc55eae2230c017',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/afb862a421a634509457345ba9bc6b50.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aec51ed95d4111d4a292e03628c52290',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/836a774691feb44fcfcf732a21085f80.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5e9d90a4143457c0563273cce8487f0',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/748bef5722427533cfae3e1d63c25482.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ef7f44c70a92bcb932ff66b1a05df6d',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/86a9fa37672b55fcd26578a124000a18.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00784469c0233b852e5691f2c410ccc1',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/36c62d2af6a99d90f67ed10c1df9693e.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00acf9e3d6b72b9d9a5cb7fcc658155c',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/98ddb536876dbb411117e05136b48c6c.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3682d925e738ec2ffa4b1ee2334802e',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/1438bdb2052fecdc672c70b8075e7b0e.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ad461c398802ce24aa479705e5f353d',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/6eee788ff5bdfc10c51adbe10d0a6aac.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e35f26b7ad2f24e624a286d4180a86d',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/b2645adde024247e98e5639198b05e33.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47597e8b72cd34cfeea4050eb20a4b67',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/f74d06020c9b6e65244c790d8992feaf.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5506cfd2649e8d4b0c4881d973ace7fd',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/a7e1189e8806f8eb2c0c3eb7b99732b1.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0335f97bd7989a63b9396ed26efdf764',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/740c9f473988fb8132548ae90be18045.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd01c8a9b156799472df988672d3a8ffd',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/8ecc3ab97fdbe9a15eb96554e7190e90.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b678cc992bbfe14602ef113ece78dc8e',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/393a5b44d113c1f6c76c85cd0afe0759.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '649e60d026fec6f3043d32bb980d802f',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/a0fcc675f6cb73d3ee82c5aaa0639308.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '54ece1ef28e4543ae3544bc5b119807b',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/8684f21d72794aa20a9f124578317863.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f627cdba1ad846b04c2697ebff9538b',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/1101efabe06617a93df8be8efc664fce.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bec025c3f5cbcf0bdb490f0436222c4',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/4fd4cbe876ef234aadc542627506b1ba.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '304b3d20dabdc97ef765c9af42b44f37',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/63610d3560562da1799a48b8255a6dc1.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44a2de6a5cad9fb087933be5d29360cd',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/34f6873782de0b815e41033a43a6b96e.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84b901b48fa4f1e9ee5d61ac785a39d5',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/99d54a7204c90f142adc7a7ab0f5bc12.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0facd2fd04c9e8fcf3b07ea67e6dbcf1',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/a7870876b3dcb1a8155a77ed2b20b82a.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52b5fa014b3ca9684021c7a23e6bb208',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/0bdc7155e063948f520c9d56e0556b9b.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afbe2461a4495f324f1e34516c92b5b9',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/96d8cda5c50387dea9749f28a902755a.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '278bcfd4560eb852b143250403283f78',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/f47d61da9559969d437eff6e5c093339.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49d58317d27189acaa1754d254939c69',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/6205b2d30e168bab858a191e3bb433b2.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69dfddc6683bc1421270c9279ab4d7d3',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/c053592cf2c6811d6c245d867c72af4c.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '880619bc6482fadb332938001cedad23',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/96544212404eec50ef32f90be19ef8a9.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3206e4f69fcc6770a627048d1d1aefbc',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/883b1818b126161306f557b2b1674c60.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ed99c116fe59b3d09071097eae9a36d',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/f3788a33c7e6a8c8a4019c8022f937c9.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c23530d7a6178edf48c3d1bdada0f5b',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/23da4948c59408424882767bbbe67fba.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1967bee7e4eb95766d8d33778356265',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/422056bbbf39d4b50ea9aec5702c08d8.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28bb2930c5e1bf4658a9d8425d0b0c20',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/c9d25ebfaac368b364a7bebe1c39d2d5.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4c940f98def43eba8c587c6e62c2a9f',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/719faaad7ff1704c27a692cc4e48a7c4.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef6dc8dc0c2bc2c2e8f712bd374c0a55',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/564b5a2815d248490484a082fbaa7282.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f7117ede943b92e013902ca8279139c',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/a1daafec6850900c8ac51c768b5c0e13.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '624766c0547ae4e5db899e890d1a75bb',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/0de3902f8fa3c334e585c23af2b7309d.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f73ec68c9c9f8e7ea06e093ca0e9015',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/958379a2419aca13a9fd92d6a3d68813.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4cf4686ab179d34aca1124e210fd4e4',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/edea7c7a93a755b47fbb39e1d1216254.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f6b1b1043fc504ee25c0a815fe353b9',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/b77a92256c1df215d04f1788b63ba992.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bfa8ff02a90220fe7a27c12b0c6cfbb',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/6df90a0c038e83b578f636606cb85b17.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64fb521be634fcde3e2b3ac4afabb2e8',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/db1eb582c0fc601875d995d043f03530.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1a016b994874576d0203858bb35d5f8',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/55eabd1709be921c307d2039ae8fb400.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea9b1b8f99a4df814cf3e0719d2823f1',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/943a976b4326e9e57be8aa8b51ec6a71.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec81a5bba777b3121f4ffceb0f542fc7',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/f4a5f0382c9823f16a659353fdfe997f.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcc1aec26776940a7e03aeca32c63e2a',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/44f98482de313f2ead4837debe78de23.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e9b63ca524e51b73823bc740dd2c58a',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/a3a2647e0d82dab04154370b2e0bc63e.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b71a7c6ad39e90ff698cff758671089',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/9327f434950e428350356ff3d781ef85.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'adb4862c26064925182341c67496ea36',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/8c1e50f2b20ee9c2bf9f81ab6a7b7ed9.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c8acf4e9751abb1fe616c6347993c04',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/1badb17f2c8e949eb85335eccd4d68dc.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f330c26f95388f120c7da63a924e622d',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/0bcefff38c0e73e32c5fa194889ffd54.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0deef270404251a45b0be3f59da0ddb0',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/eecc649db44d51b710f8087f454beec1.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed854a8a807fb141119bed1d4855b62b',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/31d87fa6a2004d9a8c14f4e2b19cfe8a.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca954cb67f82217cab2b59254120c969',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/666643db5cc64cfacea23cc0f38df274.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bc6dad117c5729c2a64f34addd94270',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/42042aa48344bf320fa64e23e44adc8e.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e939e22b8d74d292bb4fca3f652c615f',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/3847d03a1ada5eb7edb3c1e8cd755de9.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79bb6b5b6203bc4be2bacc17ed5371e2',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/a9c4e371cfd85e2cf7e5935e9dd11627.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc7ef1085fc9fed4ba58c7de125bb1f2',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/4d06f49449123338d234e1ed271a6a11.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8008ae0dd11c512ff193224f5d2f9714',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/5e1bbf34e0a4630832630aeb0ed56949.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d5e4be41ce610e1f51fd00b4366dfbe',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/398d6521f49a219dfd63022b6e3e3e68.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf145c17f89b7173e8e64aef1bae99ff',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/40121391967d01243a2f468080fac6ec.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea8eb19033c9030c140718c602c46057',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/d8e298ba3e79effbb2d19f347c1ec4d8.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0636453b4d6f6ce673873a975cb5b275',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/6d8e73c4da4d2d3ed1444dea72a0bce7.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f553c3f75a3f054ae81a678a8540eff4',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/fc2542588dd193f76d1f47240c3d3a85.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'a707c26dfd435cf4c8de3b9f29ce3bd8',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/8785d6ca50f777730f2a892e41be6d14.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '3bdef3a655c1afcf095bb61cb229b59d',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/3db0b051dcc54e18f49623c3ee7ff56e.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '85c32e20284a89dd7a30a63dd977c048',
      'native_key' => 1,
      'filename' => 'modUserGroup/ade39964c70b288ae3ac9f5866c5175b.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '7334ebaa5356cac1268bba73754a8577',
      'native_key' => 1,
      'filename' => 'modDashboard/b565a31ade90594f72b36281bf029f22.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'f30af0e66ee49580d53379e83b553bca',
      'native_key' => 1,
      'filename' => 'modMediaSource/a17e646267355bb6f5c5a2ffead4b0d6.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '4a6b2b8899f4e951b2d7ac7ebe4fd20a',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/096c343cb9731d89ab0946ce31f7cab7.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'bd572fa61e10fc3b810c6494c9fb4248',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/bb8d3ad02e7955f0987689a617d00a3b.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '92d0606b87b135c8ecef21b74daf8726',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/40a7a88ee1f1cd720ca1a2bc3c9923b2.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '32505e5dbbf4bae81c3d528b013d5741',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/b741d7d7c21dce9dc26004288b65a62a.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '147e8c81928469d547ef87cf7295384c',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/75c7647dbcbdc886bc7fc4d7116fbb8a.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '85e7d0423c525eeddfd35d973a870c72',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/6afe37be6730518fca5bfad0c215de09.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '89c4a6466b82ae6ac1d67317e648b8d9',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/8e10493defc7af3b0a9c78e2827e27a2.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '8613850f37cb41062646f2aa5f79b997',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/b4c2e1be822d44fb32b383ae29084982.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '834c81284cd723a6b5184e8618eb0f8b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/32c3233becad980898c00ddaa118389e.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e74c6cc1eaca0878429abdafe3f8ee0d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/80f3a9317fa2fb12d5a9da5b4a1294ba.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '00547c512ed51f856ad3257c2ab1e32a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1a46283773f6ba67ba04f2108cbbd4de.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '77e216d4aaa974af007aeb61b76d2726',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/b11a68ece3f9d61d7e8e853e1cdf5180.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '9521c3f13e8560c91fb0522d69cfe731',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/581b8b8697b88eb8c094ec35a0f35568.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'fb19554405cfb9218821ca4e67d94e3b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/23a49b7304a1eecbe0cf257d45ed7fb0.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'cd05731ff51488af443d471eb4f28a32',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/626220fae5210f2ec80c34a4cd65cf63.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '0cfe532a63dec4fbbb615f0bf4028430',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b0e2641c69fe75a265e1f6d1bca094af.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '38583971e721c47fff3fa556efcf3ce0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/a6521924b16e5eb3e6c9ffd13d66e22e.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '2e8f5766c1d7c1c168237cdea8a410a9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/e455914d065a08ab1f4c02621fd65bbb.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'f59f6119fdd5bac4200d0daeb29279d1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/223b36235a52bf67c8fff296ab43da83.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '0d62fcec7d8a5932e3efa04edbbc420e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/9b54bfdb426d3415bad5011688ab278f.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9c5c18efc0ea99033a5b33d47580de7a',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/04b4ec170453e64c8b627d69eb457eda.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2b4a9371247cdf95ea1627d817694309',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/51bcc1a4bc1c4c94a8a132bbc9743a26.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f1dc7606d0d01db22d62807a5fdfca7f',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/ad512c1c0efd8d5d56705cbdc51cb384.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '98c675b4d9c79b3e4ea09c6b66ceb518',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/bbd55b485444be2d287ae1902e71bbba.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b0338578fde00fb2cb769c7c34f51092',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/ef8af7ff2f37571048bcb6696801d90e.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e38d9b9445075eb0ea0f785f55aec16f',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/ab4278829b7b88d3f0adee1b7e5e6540.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '05c18a3e75a458a7d1fc9c67490377c0',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/fa9b362a6668ece8859942fd38c8b856.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '77b09cf62ebb791607ea527172fc78cd',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/4b57f77f9d77739fb7a9b7ae3bd03785.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6bd5b4127af8ee4c13a005ff33f4868d',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/37684c00795ee0e534158ca824a57442.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c08f585a3e8c591064a895e67b6be191',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/0468dfb3a6d72f13c5512697abbb95e8.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '561cd765f842440e005da6a0eb5c8ae8',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/80a05c7e0d2b98aef25c11bc46c05742.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a89c1bad938134f72d7b497d00723b20',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/1f9c13733977918f630d69a13eb51f44.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'd04cd6f6f66fb9fd5513d5ebcad4bc01',
      'native_key' => 'web',
      'filename' => 'modContext/5f3416170806fe1a0e26927788f90c85.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'c302df310db9dd8ea194a8ac5fd62fa4',
      'native_key' => 'mgr',
      'filename' => 'modContext/9c54115973b570fcaee874a9bad59359.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '45a74a40c0c509ff005a5cd21142c65e',
      'native_key' => '45a74a40c0c509ff005a5cd21142c65e',
      'filename' => 'xPDOFileVehicle/1008d29a01e7091350a45441edf7930c.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0728c75f59eb85d547d746956769b910',
      'native_key' => '0728c75f59eb85d547d746956769b910',
      'filename' => 'xPDOFileVehicle/a91be4f2e40d67389344a5e652056803.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd61ae82c584eed8c1d9f6705395a13fe',
      'native_key' => 'd61ae82c584eed8c1d9f6705395a13fe',
      'filename' => 'xPDOFileVehicle/ccc06488aaf47ecc71bdb01649feb1cf.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '94f0d0560dda15f65072f62c5da79df7',
      'native_key' => '94f0d0560dda15f65072f62c5da79df7',
      'filename' => 'xPDOFileVehicle/30963b7eabfeff616e37446f76e1791e.vehicle',
    ),
  ),
);