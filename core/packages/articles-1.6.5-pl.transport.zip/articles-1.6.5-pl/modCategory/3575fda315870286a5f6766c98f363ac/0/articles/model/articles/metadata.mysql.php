<?php

$xpdo_meta_map = array (
  'modResource' => 
  array (
    0 => 'ArticlesContainer',
    1 => 'Article',
  ),
);